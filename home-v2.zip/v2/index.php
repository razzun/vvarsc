<?
	putenv("TZ=US/Pacific");

	include_once('dbconn/dbconn.php');
	include_once('inc/functions.php');
	
	if (!isset($_SESSION['id'])) {
		include_once('inc/login.php');
	}
	if (isset($_SESSION['id'])) {
		include_once('inc/logout.php');
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<? include_once('inc/meta.php'); ?>
</head>
<body>
<div id="header">
	<div id="logo">
		<h1><a class="title" href="index.php">ProjectXFire.com</a></h1>
		<h2><script src="inc/clock.js" type="text/javascript"></script></h2>
	</div>
	<div id="menu">
		<? include_once('inc/menu.php'); ?>
	</div>
</div>
<div id="wrapper">
	<div id="content">
		<div id="sidebar">
			<div id="login" class="boxed">
				<h2 class="title">User Account</h2>
				<div class="content">
					<?
						if(!$_SESSION[id]) {
							include_once('inc/loginbox.php');
						}
						else {
							if(isadmin($_SESSION[id])) {
								include_once('admin/account.php');
							}
							else {
								include_once('user/account.php');
							}
						}
					?>
				</div>
			</div>
			<div id="updates" class="boxed">
				<h2 class="title">Recent Blog Entries</h2>
				<div class="content">
					<? include_once('inc/recentblog.php'); ?>
				</div>
			</div>
		</div>
		<div id="main">
			<? include_once('inc/page_switch.php'); ?>		
		</div>
	</div>
	<div style="clear: both;">&nbsp;</div>
</div>
<div id="footer">
	<? include_once('inc/footer.php'); ?>
</div>
</body>
</html>