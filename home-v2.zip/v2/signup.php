<div id="welcome" class="post">
	<h2 class="title">Signup</h2><br />
		<p>All fields are required.  Email the <a href="mailto:webmaster@projectxfire.com?subject=Signup Issues">webmaster</a> if you have any problems.</p>
</div>
<div id="login" class="boxed">					
	<div class="content">
		<form id="signup" method="post" action="index.php?page=register">
			<fieldset>
			<table border="0">
				<tr>
					<td align="right"><label for="fname_input">First Name: </label></td>
					<td><input id="fname_input" type="text" name="fname_input" tabindex="1" value="" /></td>
					<td align="right"><label for="lname_input">Last Name: </label></td>
					<td><input id="lname_input" type="text" name="lname_input" tabindex="2" value="" /></td>
				</tr>
				<tr>
					<td align="right"><label for="location_input">Location: </label></td>
					<td><input id="location_input" type="text" name="location_input" tabindex="3" value="" /></td>
					<td align="right"><label for="occupation_input">Occupation: </label></td>
					<td><input id="occupation_input" type="text" name="occupation_input" tabindex="4" value="" /></td>
				</tr>
				<tr>
					<td align="right"><label for="uname_input">Username: </label></td>
					<td><input id="uname_input" type="text" name="uname_input" tabindex="5" value="" /></td>
					<td align="right"></td>
					<td></td>
				</tr>
				<tr>
					<td align="right"><label for="password_input">Password: </label></td>
					<td><input id="password_input" type="password" name="password_input" tabindex="6" value="" /></td>
					<td align="right"><label for="password2_input">Password Again: </label></td>
					<td><input id="password2_input" type="password" name="password2_input" tabindex="7" value="" /></td>
				</tr>
				<tr>
					<td align="right"><label for="email_input">Email: </label></td>
					<td><input id="email_input" type="text" name="email_input" tabindex="8" value="" /></td>
					<td align="right"></td>
					<td></td>
				</tr>
				<tr>
					<td align="right" colspan=4><input id="signup_submit" type="submit" name="signup_submit" tabindex="9" value="Submit" /></td>
				</tr>
			</table>
			</fieldset>
		</form>
	</div>
</div>