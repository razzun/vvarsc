<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<?
	if($_POST[comment_delete]){
		$del_verify = @mysql_query("SELECT comm_id, user_id
			 FROM COMMENTS c
			 WHERE comm_id = $_POST[commid]") or die(mysql_error());
		
		if (mysql_num_rows($del_verify) == 1) {			
			$del_comm = @mysql_query("DELETE FROM COMMENTS WHERE comm_id = $_POST[commid]") or die(mysql_error());
			$msg = "<div class=greenText>Comment deleted.</div>";
		}
		else {
			$error = "<div class=redText>There was an error deleting the information from the database.  Please contact the <a href=\"mailto:webmaster@projectxfire.com?subject=Error Deleting Comment\">webmaster</a> for details.</div>";
		}
	}
	else {
		$error = "<div class=redText>There was an error.  Please contact the <a href=\"mailto:webmaster@projectxfire.com?subject=Error Deleting Comment\">webmaster</a> for details.</div>";
	}
	echo $error;
	echo $msg;
?>
<?
			}
		}
	}
?>