<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<script language="JavaScript" type="text/javascript" src="editor/scripts/wysiwyg.js"></script>
<script type="text/javascript" src="editor/scripts/wysiwyg-settings.js"></script>
<script type="text/javascript">
	WYSIWYG.attach('post_comment'); // default setup
</script>
		
<div id="welcome" class="post">
	<h2 class="title">Post Comment</h2>
</div>
<div id="login" class="boxed">					
	<div class="content">
		<form id="comment" method="post" action="index.php?page=comment_blog_post_code">
			<fieldset>
					<textarea id="post_comment" name="post_comment"></textarea>
					<input name="submit" type="submit" id="submit" value="Submit"><input name="id" type="hidden" name="id" value="<? echo $_GET[blogid]; ?>" />
			</fieldset>
		</form>
	</div>
</div>
<?
			}
		}
	}
?>