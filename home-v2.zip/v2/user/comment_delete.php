<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<div id="delCom" class="post">
	<h2 class="title">Delete Comment?</h2><br />
<?
	$comm_id = $_GET[commid];

	$delete_comments = @mysql_query("SELECT comm_id, DATE_FORMAT(comm_date,'%m/%d/%Y') comm_post_date, user_id
					 FROM COMMENTS c
					 WHERE comm_id = $comm_id") or die(mysql_error());

	if (mysql_num_rows($delete_comments) == 1) {
		while($row = mysql_fetch_array($delete_comments)) {
			$comm_post_date = $row['comm_post_date'];
		} //End while	
?>
		<p><center>Are you sure you want to delete the comment posted on: <? echo $comm_post_date; ?>?</center></p>
</div>
<div id="login" class="boxed">					
	<div class="content">
		<form id="delete_comment" method="post" action="index.php?page=comment_delete_code">
			<fieldset>
				<center>
					<input id="commid" type="hidden" name="commid" value="<? echo $comm_id; ?>" />
					<input id="comment_delete" type="submit" name="comment_delete" value="Delete" />
				</center>
				<p><center><a href="<? echo $_SERVER['HTTP_REFERER']; ?>">Take me back and do not delete my comment</a></center></p>
			</fieldset>
		</form>
	</div>
</div>
<?
	}
	else {
		echo "<div class=redText>There was an error retrieving the information from the database.  Please contact the <a href=\"mailto:webmaster@projectxfire.com?subject=Error Deleting Comment\">webmaster</a> for details.</div>";
	} //End Else
?>
<?
			}
		}
	}
?>