<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<?
	if($_POST[submit]) {
		$comm_body = $_POST['comment_edit'];
		$comm_id = $_POST['commid'];

		$update_welcome = mysql_query("UPDATE COMMENTS SET comm_body = '$comm_body'
								WHERE comm_id = $comm_id
								AND user_id = $_SESSION[user_id]") or die(mysql_error());

		$confirmMsg = "<div class=greenText>Your comment has been updated.</div>";
	} //End if form_submit == true
	else {
		$errorMsg = "<div class=redText>There was an error and your comment was not updated.</div>";
	} //End else
	
	echo $confirmMsg;
	echo $errorMsg;
?>
<?
			}
		}
	}
?>