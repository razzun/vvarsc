<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<p><a href="index.php?page=password_change" title="Change Your Password">Change Password</a><br />
<a href="index.php?page=email_update" title="Changed Emails? Update it">Update Email</a><br />
<!-- <a href="index.php?page=profile_update" title="Update Your Profil.">Update Profile</a><br /> -->
<a href="index.php?page=user_comment_list" title="A List of All Your Comments">Your Comments</a><br />
Last Login:<br /><?
					if($_SESSION['user_past_login'] == false) { echo "<i>Never</i>";} 
					else { echo $_SESSION['user_past_login']; }
				?><br />
				<? if($_GET[scheck] == '2'){
					echo "<div class=redText>You do not have proper permissions to view that page.</div><br />" ;
				} ?></p>
<?
			}
		}
	}
?>