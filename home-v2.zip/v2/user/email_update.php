<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<div id="welcome" class="post">
	<h2 class="title">Update Your Email</h2><br />
		<p>Please make sure to keep your email updated.  If you do not, you will not recieve emails for password changes or news about the site.</p>
</div>
<div id="login" class="boxed">					
	<div class="content">
		<form id="update_email" method="post" action="index.php?page=email_update_code">
			<fieldset>
				<label for="user_new_email">Email:</label><br />
				<input id="user_new_email" type="text" name="user_new_email" value="" /><br />
				<input id="email_submit" type="submit" name="update_email" value="Submit" />
			</fieldset>
		</form>
	</div>
</div>
<?
			}
		}
	}
?>