<?
	if($_POST[pass_change]){
		if($_POST[user_email] !='' && $_POST[user_uname] != '') {
			srand(date("s"));
			$possible="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
			$str="";
			while(strlen($str) < 8) {
				$str.=substr($possible,(rand()%(strlen($possible))),1);
			}
			$password = $str;	        
	        $password2 = md5($password);
	        
	        $check = mysql_query("SELECT user_uname, user_email FROM USERS WHERE user_uname ='$_POST[user_uname]' AND user_email = '$_POST[user_email]'");
	        $count = mysql_num_rows($check);
	        
	        if($count == 0){
	        	$error = "<div class=redText>That email and username combination did not match.</div>";
	        }
	        elseif($count == 1) {
	        	$now = date("Y-m-d H:i:s");
		        $update_password = mysql_query("UPDATE USERS SET user_password = '$password2', USER_PASS_CHANGE ='$now' WHERE user_email = '$_POST[user_email]' AND user_uname = '$_POST[user_uname]'");
				
				$email_send = $_POST['user_email'];
				$headers =  'From: webmaster@projectxfire.com' . "\r\n" . 
							'Reply-To: webmaster@projectxfire.com' . "\r\n" .  
							'X-Mailer: PHP/' . phpversion(); 
				$subject = "Your Password Has Been Changed for ProjectXFire.com"; 
				$message = "Hello " . $_POST[user_uname] .".  You recently requested a new password.  Your new password is " . $password . ".  Please log in as soon as possible and change this to something you will remember.\n\n Thanks.\n\n Russ Teicheira\n ProjectXFire.com\n"; 
				if(mail($email_send, $subject, $message, $headers)) {
					$msg = "<div class=greenText>Password changed.  An email was sent to the email attached to your account.</div>"; 
				} 
				else { 
					$error = "<div class=redText>The email was not sent. Please contact the <a href=\"mailto:webmaster@projectxfire.com?subject=Failed Password Change Email\">webmaster</a> for help.</div>"; 
				}
			} //End Elseif Check == 1
		}
		else {
			$error = "<div class=redText>Please fill in all fields.</div>";
		}
	}	
	echo $error;
	echo $msg;
?>