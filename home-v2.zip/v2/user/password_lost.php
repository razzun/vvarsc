<div id="welcome" class="post">
	<h2 class="title">Change Lost Password</h2><br />
		<p>To change your password please fill in the information below.  A new password will be generated and sent to your email.  You can then log back in and change the password to whatever you want.</p>
</div>
<div id="login" class="boxed">					
	<div class="content">
		<form id="lost_password" method="post" action="index.php?page=pword_lost_code">
			<fieldset>
			<label for="email">Email:</label><br />
			<input id="user_email" type="text" name="user_email" value="" /><br />
			<label for="username">Username:</label><br />
			<input id="user_uname" type="text" name="user_uname" value="" /><br />
			<input id="password_submit" type="submit" name="pass_change" value="Submit" />
			</fieldset>
		</form>
	</div>
</div>