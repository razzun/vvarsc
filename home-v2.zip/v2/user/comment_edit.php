<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
	<script language="JavaScript" type="text/javascript" src="editor/scripts/wysiwyg.js"></script>
	<script type="text/javascript" src="editor/scripts/wysiwyg-settings.js"></script>
	<script type="text/javascript">
		WYSIWYG.attach('comment_edit'); // default setup
	</script>
	<div id="welcome" class="post">
			<h2 class="title">Edit Your Comment</h2>
	<?
		$comm_id = $_GET[commid];
	
		$comm_get = @mysql_query("SELECT comm_id, comm_body
			 FROM COMMENTS
			 WHERE comm_id = $comm_id
			 AND user_id = $_SESSION[user_id]") or die(mysql_error());
		
		if (mysql_num_rows($comm_get) == 1) {
			while($row = mysql_fetch_array($comm_get)) {
				$comm_body = $row['comm_body'];
			} //End while	
	?>
	</div>
	<div id="login" class="boxed">					
		<div class="content">
			<form id="comment" method="post" action="index.php?page=comment_edit_code">
				<fieldset>
					<textarea id="comment_edit" name="comment_edit"><? echo $comm_body; ?></textarea>
					<input id="commid" type="hidden" name="commid" value="<? echo $comm_id; ?>" />
					<input name="submit" type="submit" id="submit" value="Submit" />
				</fieldset>
			</form>
		</div>
	</div>
	<?
		}
		else {
			echo "<div class=redText>There was an error retrieving the information from the database.  Please contact the <a href=\"mailto:webmaster@projectxfire.com?subject=Error Editing Comment\">webmaster</a> for details.</div>";
		}
	?>
<?
			}
		}
	}
?>