<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<div id="welcome" class="post">
	<h2 class="title">List of Your Comments</h2><br />
	<table border=1 style="border-collapse: collapse" width="550">
		<tr>
			<td align="center" width="45%"><strong>Your Comment</strong></td>
			<td align="center" width="25%"><strong>Comment Post Date</strong></td>
			<td align="center" width="30%"><strong>Blog Post Date</strong></td>
		</tr>
		<?
			$get_user_comments = @mysql_query("SELECT comm_id, c.blog_id b_id, c.user_id u_id, DATE_FORMAT(b.blog_date,'%M %d, %Y') blog_post_date, LEFT(b.blog_title, 25) b_title, DATE_FORMAT(comm_date,'%M %d, %Y') comm_post_date, comm_body
					 FROM COMMENTS c
					 LEFT JOIN BLOGS b
					 	on c.blog_id = b.blog_id
					 WHERE c.user_id = $_SESSION[user_id]
					 ORDER BY c.blog_id DESC") or die(mysql_error());
			
			if (mysql_num_rows($get_user_comments)) {			
				while($row = mysql_fetch_array($get_user_comments)) {
					$comm_id = $row['comm_id'];
					$blog_id = $row['b_id'];
					$user_id = $row['u_id'];
					$blog_post_date = $row['blog_post_date'];
					$blog_title = $row['b_title'];			
					$comm_post_date = $row['comm_post_date'];
					$comm_body = $row['comm_body'];
					
					echo "
							<tr>
								<td align=\"left\" valign=\"top\"><small>$comm_body<br /><a href=\"index.php?page=comment_edit&commid=$comm_id\">Edit</a> | <a href=\"index.php?page=comment_delete&commid=$comm_id\">Delete</a></small></td>
								<td align=\"left\" valign=\"top\"><small>$comm_post_date</small></td>
								<td align=\"left\" valign=\"top\"><small><a href=\"index.php?page=full_blog&blogid=$blog_id\">$blog_title</a><br />$blog_post_date</small></td>
							</tr>
					";
				} //End while
			}
			else {
				echo "
					<tr>
						<td align=\"center\" valign=\"top\" colspan=3>You have not made any comments yet.</td>
					</tr>
				";
			}
		?>
	</table>
</div>
<?
			}
		}
	}
?>