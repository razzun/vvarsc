<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<div id="welcome" class="post">
	<h2 class="title">Change Password</h2><br />
		<p>To change your password please fill in the information below.</p>
</div>
<div id="login" class="boxed">					
	<div class="content">
		<form id="change_password" method="post" action="index.php?page=pword_change_code">
			<fieldset>
			<label for="user_old_pword">Old Password:</label><br />
			<input id="user_old_pword" type="password" name="user_old_pword" value="" /><br />
			<label for="user_new_pword">New Password:</label><br />
			<input id="user_new_pword" type="password" name="user_new_pword" value="" /><br />
			<label for="user_new_pword_retype">New Password Retype:</label><br />
			<input id="user_new_pword_retype" type="password" name="user_new_pword_retype" value="" /><br />
			<input id="password_submit" type="submit" name="pass_change" value="Submit" />
			</fieldset>
		</form>
	</div>
</div>
<?
			}
		}
	}
?>