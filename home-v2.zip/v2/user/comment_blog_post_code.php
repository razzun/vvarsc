<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<?
	$today = date("Y-m-d H:i:s"); 

	if($_POST[submit]) {
		$comm_body = $_POST[post_comment];
		$blog_id = $_POST[id];

		$post_comment = mysql_query("INSERT INTO COMMENTS(`blog_id`, `user_id`, `comm_date`, `comm_body`) VALUES('$blog_id', '$_SESSION[user_id]', '$today', '$comm_body')") or die(mysql_error());

		$confirmMsg = "<div class=greenText>Comment has been posted.</div>";
	} //End if form_submit == true

	else {
		$errorMsg = "<div class=redText>There was an error and the comment was not posted.</div>";
	} //End else
	
	echo $confirmMsg;
	echo $errorMsg;
?>
<?
			}
		}
	}
?>