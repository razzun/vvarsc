<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<?
	if($_POST[update_email]){
		if($_POST[user_new_email] !='') {
			if (valid_email($_POST[user_new_email]) == TRUE) {
				if (checkUnique('user_email', $_POST['user_new_email'])==TRUE) {
					$update_password = mysql_query("UPDATE USERS SET user_email = '$_POST[user_new_email]' WHERE user_uname = '$_SESSION[user_uname]'");
					$msg = "<div class=greenText>Your email has been changed to <a href=\"mailto:" . $_POST[user_new_email] . "\">" . $_POST[user_new_email] . "</a>.</div>";
				}
				else {
					$error = "<div class=redText>That email is already in use.  Please enter a unique email address.</div>";
				}
			}
			else {
				$error = "<div class=redText>The email address you entered is not valid.</div>";
			}
		}
		else {
			$error = "<div class=redText>Please enter a valid email address.</div>";
		}
	}
	echo $error;
	echo $msg;
?>
<?
			}
		}
	}
?>