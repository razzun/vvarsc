<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<?
	if($_POST[pass_change]){
		if($_POST[user_old_pword] !='' && $_POST[user_new_pword] != '' && $_POST[user_new_pword_retype] != '') {
			if($_POST[user_new_pword] == $_POST[user_new_pword_retype]) {
				$password_old = md5($_POST[user_old_pword]);  
		        $password_new = md5($_POST[user_new_pword]);
		        
		        $check = mysql_query("SELECT user_password FROM USERS WHERE user_uname ='$_SESSION[user_uname]' AND user_password ='$password_old'");
		        $count = mysql_num_rows($check);
		        
		        if($count == 0){
		        	$error = "<div class=redText>Your old password did not match what is stored in the database.</div>";
		        }
		        elseif($count == 1) {
		        	$now = date("Y-m-d H:i:s");
			        $update_password = mysql_query("UPDATE USERS SET user_password = '$password_new', USER_PASS_CHANGE ='$now' WHERE user_uname = '$_SESSION[user_uname]'");
			        $msg = "<div class=greenText>Your password has been changed.</div>";
				} //End Elseif Check == 1
			}
			else {
				$error = "<div class=redText>Your new passwords did not match.</div>";
			}
		}
		else {
			$error = "<div class=redText>Please fill in all fields.</div>";
		}
	}
	echo $error;
	echo $msg;
?>
<?
			}
		}
	}
?>