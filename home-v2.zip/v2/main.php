	<?php	
		$blog_welcome_get = @mysql_query("SELECT b.blog_id b_id, DATE_FORMAT(b.blog_date,'%M %d, %Y at %l:%i %p') blog_post_date, b.blog_title, b.blog_body, u.user_id, u.user_fname, user_lname, count(comm_id) comm_count
			 FROM BLOGS b
			 LEFT JOIN USERS u
			 	on b.user_id = u.user_id
			 LEFT JOIN COMMENTS c
			 	on b.blog_id = c.blog_id
			 WHERE b.blog_id = 0
			 GROUP BY c.blog_id") or die(mysql_error());
		
		while($row = mysql_fetch_array($blog_welcome_get)) {
			$blog_id = $row['b_id'];
			$blog_post_date = $row['blog_post_date'];
			$blog_title = $row['blog_title'];
			$user_fname = $row['user_fname'];
			$user_lname = $row['user_lname'];
			$comm_count = $row['comm_count'];
			
			if(isset($_SESSION['id']) && isadmin($_SESSION['id'])) {
				$replace_what = "<strong>Guest</strong>";
				$replace_with = "<strong><font color=\"#ff0000\">" . get_fname($_SESSION['id']) . "</font></strong>";
				$blog_body = str_replace($replace_what, $replace_with, $row['blog_body']);
			}
			elseif(isset($_SESSION['id']) && !isadmin($_SESSION['id'])) {
				$replace_what = "<strong>Guest</strong>";
				$replace_with = "<strong><font color=\"#0000cc\">" . get_fname($_SESSION['id']) . "</font></strong>";
				$blog_body = str_replace($replace_what, $replace_with, $row['blog_body']);
			}
			else {
				$blog_body = $row['blog_body'];
			}
			
			echo "
				<div id=\"welcome\" class=\"post\">
					<h2 class=\"title\">$blog_title</h2>
					<h3 class=\"date\"><span class=\"time\">Updated: $blog_post_date</span></h3>
					<div class=\"meta\">
						<p>Posted by $user_fname $user_lname<br />
						<a href=\"index.php?page=comments&blogid=$blog_id#comments\">Comments ($comm_count)</a></p>
					</div>
					<div class=\"story\">
						$blog_body
					</div>
				</div>
			";
		} //End while
	?>