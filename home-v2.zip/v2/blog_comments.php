<?	
	$rowsPerPage = 5;
	$pageNum = 1;
	
	if(isset($_GET['pageNav'])) {
		$pageNum = $_GET['pageNav'];
	}
	
	$offset = ($pageNum - 1) * $rowsPerPage;
	
	$blog_get_id = $_GET['blogid'];
	
	$get_blogs = @mysql_query("SELECT b.blog_id b_id, DATE_FORMAT(b.blog_date,'%M %d, %Y at %l:%i %p') blog_post_date, b.blog_title, b.blog_body, u.user_id, u.user_fname, user_lname
                     FROM BLOGS b
                     LEFT JOIN USERS u
                         on b.user_id = u.user_id
                     WHERE b.blog_id = '$blog_get_id'
                     ORDER BY b_id DESC") or die(mysql_error());
	
	while ($row = @mysql_fetch_array($get_blogs)) {
        $blog_id = $row['b_id'];
        $blog_post_date = $row['blog_post_date'];
        $blog_title = $row['blog_title'];
        $user_fname = $row['user_fname'];
        $user_lname = $row['user_lname'];
        $blog_body = $row['blog_body'];
        
        $get_comments = @mysql_query("SELECT b.blog_id, comm_id, c.user_id, user_uname, DATE_FORMAT(comm_date,'%M %d, %Y at %l:%i %p') comm_post_date, comm_body
                        FROM COMMENTS c
                        LEFT JOIN BLOGS b
                            on c.blog_id = b.blog_id
                        LEFT JOIN USERS u
                        	on c.user_id = u.user_id
                        WHERE b.blog_id = '$blog_get_id'
                        ORDER BY comm_id ASC
                        LIMIT $offset, $rowsPerPage") or die(mysql_error());
        
			if((isset($_SESSION['id']) && isadmin($_SESSION['id'])) && $blog_get_id == 0) {
				$replace_what = "<strong>Guest</strong>";
				$replace_with = "<strong><font color=\"#ff0000\">" . get_fname($_SESSION['id']) . "</font></strong>";
				$blog_body = str_replace($replace_what, $replace_with, $row['blog_body']);
			}
			elseif((isset($_SESSION['id']) && !isadmin($_SESSION['id'])) && $blog_get_id == 0) {
				$replace_what = "<strong>Guest</strong>";
				$replace_with = "<strong><font color=\"#0000cc\">" . get_fname($_SESSION['id']) . "</font></strong>";
				$blog_body = str_replace($replace_what, $replace_with, $row['blog_body']);
			}
			else {
				$blog_body = $row['blog_body'];
			}
        
        $count = @mysql_num_rows($get_comments);
        
        if ($count == 0) {
			$display_blog = "
				<div id=\"welcome\" class=\"post\">
					<h2 class=\"title\">$blog_title</h2>
					<h3 class=\"date\"><span class=\"time\">$blog_post_date</span></h3>
					<div class=\"meta\">
						<p>Posted by $user_fname $user_lname<br />
						<a href=\"index.php?page=comments&blogid=$blog_id#comments\">Comments (0)</a></p>
					</div>
					<div class=\"story\">
						$blog_body
					</div>
				</div>
			";
			
			$display_comments = "<p>No comments yet.  Be the first to <a href=\"index.php?page=comment_blog_post&blogid=$blog_get_id\">post something</a>.</p>";
        }
        else {
        	while ($row2 = mysql_fetch_array($get_comments)) {
                $get_comment_counts = @mysql_query("SELECT b.blog_id, count(comm_id) comm_count
	                FROM BLOGS b
	                LEFT JOIN COMMENTS c
	                    on b.blog_id = c.blog_id
	                WHERE b.blog_id = '$blog_get_id'
	                GROUP BY c.blog_id") or die(mysql_error());
        		
        		while ($row3 = mysql_fetch_array($get_comment_counts)) {
        			$comm_count = $row3['comm_count'];
        		}
        		$comm_id = $row2['comm_id']; 
                $comm_post_date = $row2['comm_post_date'];
				$comm_body = $row2['comm_body']; 
				$user_uname = $row2['user_uname'];
				
				if (isset($_SESSION[id])) {
					if (($_SESSION[user_uname] == $user_uname && $_SESSION[user_level] != 0) || ($_SESSION[user_uname] == $user_uname && $_SESSION[user_level] == 0)) {
						$editDelete = " | <a href=\"index.php?page=comment_edit&commid=$comm_id\">Edit</a> | <a href=\"index.php?page=comment_delete&commid=$comm_id\">Delete</a>";
					}
					elseif($_SESSION[user_level] == 0 && $_SESSION[user_uname] != $user_uname) {				    
				    	$editDelete = " | <a href=\"index.php?page=comment_delete&commid=$comm_id\">Delete</a>";
					}
				}
                
				$display_blog = "
					<div id=\"welcome\" class=\"post\">
						<h2 class=\"title\">$blog_title</h2>
						<h3 class=\"date\"><span class=\"time\">$blog_post_date</span></h3>
						<div class=\"meta\">
							<p>Posted by $user_fname $user_lname<br />
							<a href=\"#comments\">Comments ($comm_count)</a></p>
						</div>
						<div class=\"story\">
							$blog_body
						</div>
					</div>
					";
				
				$display_comments .= "
					<div id=\"welcome\" class=\"post\">							
						<h3 class=\"date\"><span class=\"time\">Comment posted on: $comm_post_date</span></h3>
						<div class=\"meta\">
							<p>By: $user_uname$editDelete</p>
						</div>
						<div class=\"story\">
							$comm_body
							<div class=\"bmeta\">
								<p><a href=\"index.php?page=comment_blog_post&blogid=$blog_get_id\">Post a comment</a></p>
							</div>
						</div>
					</div>
					<hr width=\"100%\" />
					";
        	}
			//Start Page breaks for Comments
			$result  = mysql_query("SELECT COUNT(comm_id) AS numrows FROM COMMENTS WHERE blog_id = '$blog_get_id'") or die('Error, query failed');
			$row     = mysql_fetch_array($result, MYSQL_ASSOC);
			$numrows = $row['numrows'];
			
			$maxPage = ceil($numrows/$rowsPerPage);
			$self = $_SERVER['PHP_SELF'] . "?page=comments&blogid=" . $blog_get_id;
			$nav  = '';
			
			for($pageNav = 1; $pageNav <= $maxPage; $pageNav++) {
				if ($pageNav == $pageNum) {
					$nav .= " $pageNav "; // no need to create a link to current page
				}
				else {
					$nav .= " <a href=\"$self&pageNav=$pageNav#comments\">$pageNav</a> ";
				}
			} //End For
			if ($pageNum > 1) {
				$pageNav  = $pageNum - 1;
				$prev  = " <a href=\"$self&pageNav=$pageNav#comments\">[Prev]</a> ";				
				$first = " <a href=\"$self&pageNav=1#comments\">[First Page]</a> ";
			}
			else {
				$prev  = '&nbsp;'; // we're on page one, don't print previous link
				$first = '&nbsp;'; // nor the first page link
			}		
			if ($pageNum < $maxPage) {
				$pageNav = $pageNum + 1;
				$next = " <a href=\"$self&pageNav=$pageNav#comments\">[Next]</a> ";
				$last = " <a href=\"$self&pageNav=$maxPage#comments\">[Last Page]</a> ";
			}
			else {
				$next = '&nbsp;'; // we're on the last page, don't print next link
				$last = '&nbsp;'; // nor the last page link
			}
			
			// print the navigation link
			$allNav .= $first . $prev . $nav . $next . $last;
        }
	}
?>

<? echo $display_blog; ?>
<? echo "<a class=\"inpage\" name=\"comments\"><h2 class=\"comments\">Comments</h2></a>"; ?>
<? echo $display_comments; ?>
<? echo $allNav; ?>