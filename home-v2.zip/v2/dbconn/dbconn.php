<?
	$connection = @mysql_connect ("localhost", "projectx_pxfire2", "pxfire20072") or die ('I cannot connect to the database because: ' . mysql_error());
	mysql_select_db ("projectx_pxfire2");
?>