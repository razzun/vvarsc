<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 1) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
	<script language="JavaScript" type="text/javascript" src="editor/scripts/wysiwyg.js"></script>
	<script type="text/javascript" src="editor/scripts/wysiwyg-settings.js"></script>
	<script type="text/javascript">
		WYSIWYG.attach('welcome_update'); // default setup
		//WYSIWYG.attach('textarea2', full); // full featured setup
		//WYSIWYG.attach('textarea3', small); // small setup
	</script>

	<?
		$welcome_get = @mysql_query("SELECT blog_id, blog_body
			 FROM BLOGS
			 WHERE blog_id = 0") or die(mysql_error());

		while($row = mysql_fetch_array($welcome_get)) {
			$blog_body = $row['blog_body'];
		} //End while $results_welcome_get
	?>
			
	<div id="welcome" class="post">
			<h2 class="title">Welcome Update</h2>
	</div>
	<div id="login" class="boxed">					
		<div class="content">
			<form id="welcome" method="post" action="index.php?page=welcome_code">
			<fieldset>
					<textarea id="welcome_update" name="welcome_update"><? echo $blog_body; ?></textarea>
					<input name="submit" type="submit" id="submit" value="Submit" />
			</fieldset>
			</form>
		</div>
	</div>
<?
			}
		}
	}
?>