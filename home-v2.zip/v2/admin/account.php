<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 1) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
Admin Area:
<p><a href="index.php?page=welcome_update" title="Update the Welcome Post">Update Welcome Post</a><br />
<a href="index.php?page=blog_post" title="Post a New Blog/News Entry">Post Blog</a><br />
<a href="index.php?page=projects_update" title="Update Projects">Update Projects</a><br />
<a href="index.php?page=about_me_update" title="Update About Me">Update About me</a><br />
<a href="index.php?page=resume_update" title="Update the Resum&eacute;">Update Resum&eacute;<br />
<a href="index.php?page=member_list" title="Members List">Members List</a><br />
<a href="index.php?page=blog_list" title="Blog List">Blog List</a><br />
<a href="index.php?page=links_update" title="Links Update">Links Update</a></p>
User Area:
<? include_once('user/account.php'); ?>
<?
			}
		}
	}
?>