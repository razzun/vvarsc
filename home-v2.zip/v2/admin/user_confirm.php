<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 1) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<?php	
	if($_GET['id']!='' && numeric($_GET['id'])==TRUE && strlen($_GET['key'])==32 && alpha_numeric($_GET['key'])==TRUE)
	{

		$query = mysql_query("SELECT user_id, user_fname, user_lname, user_uname, user_email, user_activation_key, user_active FROM USERS WHERE user_id = '".mysql_real_escape_string($_GET['id'])."'");
		
		if(mysql_num_rows($query)==1)
		{
			$row = mysql_fetch_assoc($query);
			if($row['mem_active']==1)
			{
				$error = 'This user is already active.';
			}
			elseif($row['user_activation_key']!=$_GET['key'])
			{
				$error = 'The confirmation key that was generated for this user does not match with the one entered.';
			}
			else
			{
				$update = mysql_query("UPDATE USERS SET user_active='1' WHERE user_id='".mysql_real_escape_string($row['mem_id'])."'") or die(mysql_error());
				//$msg = "Member's accout is now active.";
				
				//$row = mysql_fetch_assoc($getUser);  
				$headers =  'From: webmaster@projectxfire.com' . "\r\n" . 
						  'Reply-To: webmaster@projectxfire.com' . "\r\n" .  
						  'X-Mailer: PHP/' . phpversion(); 
				$subject = "Your ProjectXFire.com account is active!"; 
				$message = "Congratulations, ".$row['user_fname']." ".$row['user_lname']. ".  Your account for ProjectXFire.com has been approved.\nFor security reasons your username and password are not included in this email.  If you have forgotten them, please email the webmaster at webmaster@projectxfire.com.\n\nThanks for joining!"; 
				if(mail($row['user_email'], $subject, $message, $headers)) 
				{//we show the good guy only one case and the bad one for the rest. 
				  $msg = "Account for ".$row['user_fname']." ".$row['user_lname']." has been activated and an email sent to ".$row['user_email']."."; 
				} 
				else { 
				  $error = "There was an error sending an email to ".$row['user_fname']." ".$row['user_lname']."."; 
				} 
			}
		}
		else {
		
			$error = 'User not found.';
		
		}

	}
	else {

		$error = 'Invalid data provided.';

	}

	if(isset($error))
	{
		echo $error;
	}
	else {
		echo $msg;
	}
?>
<?
			}
		}
	}
?>