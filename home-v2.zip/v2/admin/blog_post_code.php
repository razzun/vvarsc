<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 1) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
<?
	$today = date("Y-m-d H:i:s"); 

	if($_POST[submit]) {
		$blog_body = $_POST['blog_body'];
		$blog_title = $_POST['blog_title'];

		$post_blog = mysql_query("INSERT INTO `BLOGS` (`user_id`, `blog_title`, `blog_body`, `blog_date`) VALUES('$_SESSION[user_id]', '$blog_title', '$blog_body', '$today')") or die(mysql_error());

		$confirmMsg = "<div class=greenText>Blog entry has been posted.</div>";
	} //End if form_submit == true
	else {
		$errorMsg = "<div class=redText>There was an error and the blod post was not posted.</div>";
	} //End else
	
	echo $confirmMsg;
	echo $errorMsg;
?>
<?
			}
		}
	}
?>