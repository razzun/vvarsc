<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 1) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
	<script language="JavaScript" type="text/javascript" src="editor/scripts/wysiwyg.js"></script>
	<script type="text/javascript" src="editor/scripts/wysiwyg-settings.js"></script>
	<script type="text/javascript">
		WYSIWYG.attach('blog_body'); // default setup
		//WYSIWYG.attach('textarea2', full); // full featured setup
		//WYSIWYG.attach('textarea3', small); // small setup
	</script>

	<div id="welcome" class="post">
		<h2 class="title">Post Blog</h2>
	</div>
	<div id="login" class="boxed">					
		<div class="content">
			<form id="blog" method="post" action="index.php?page=blog_post_code">
			<label for="blog_title">Title: </label> <input id="blog_title" type="text" name="blog_title" value="" />
			<fieldset>
					<textarea id="blog_body" name="blog_body"></textarea>
					<input name="submit" type="submit" id="submit" value="Submit" />
			</fieldset>
			</form>
		</div>
	</div>
<?
			}
		}
	}
?>