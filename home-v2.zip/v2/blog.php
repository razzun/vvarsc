<?
    $rowsPerPage = 5;
    $pageNum = 1;
    
    if(isset($_GET['pageNav'])) {
        $pageNum = $_GET['pageNav'];
    }
    
    $offset = ($pageNum - 1) * $rowsPerPage;

	$get_blogs = @mysql_query("SELECT b.blog_id b_id, DATE_FORMAT(b.blog_date,'%M %d, %Y at %l:%i %p') blog_post_date, b.blog_title, b.blog_body, u.user_id, u.user_fname, user_lname
					 FROM BLOGS b
					 LEFT JOIN USERS u
					 	on b.user_id = u.user_id
					 WHERE b.blog_id != 0
					 ORDER BY b_id DESC
					 LIMIT $offset, $rowsPerPage") or die(mysql_error());
	
	while ($row = @mysql_fetch_array($get_blogs)) {
		$blog_id = $row['b_id'];
		$blog_post_date = $row['blog_post_date'];
		$blog_title = $row['blog_title'];
		$user_fname = $row['user_fname'];
		$user_lname = $row['user_lname'];
		$blog_body = $row['blog_body'];
		
	    if(isset($_SESSION[id]) && $_SESSION[user_level] == 0) {
	    	$editDelete = " | <a href=\"index.php?page=blog_edit&blogid=$blog_id\">Edit</a> | <a href=\"index.php?page=blog_delete&blogid=$blog_id\">Delete</a>";
	   	}
		
		$get_comments = @mysql_query("SELECT b.blog_id, count(comm_id) comm_count
						FROM BLOGS b
						LEFT JOIN COMMENTS c
							on b.blog_id = c.blog_id
						WHERE b.blog_id = '$blog_id'
						GROUP BY c.blog_id") or die(mysql_error());
		
		$count = @mysql_num_rows($get_comments);
		
		if ($count == 0) {
			echo "<div id=\"welcome\" class=\"post\">
						<h2 class=\"title\">$blog_title</h2>
						<h3 class=\"date\"><span class=\"time\">$blog_post_date</span></h3>
						<div class=\"meta\">
							<p>Posted by $user_fname $user_lname<br />
							<a href=\"index.php?page=comments&blogid=$blog_id#comments\">Comments (0)</a>$editDelete</p>
						</div>
						<div class=\"story\">
							$blog_body
						</div>
					</div>";
		}
		else {
			while ($row2 = mysql_fetch_array($get_comments)) {
				$comm_count = $row2[comm_count];
				
				echo "<div id=\"welcome\" class=\"post\">
						<h2 class=\"title\">$blog_title</h2>
						<h3 class=\"date\"><span class=\"time\">$blog_post_date</span></h3>
						<div class=\"meta\">
							<p>Posted by $user_fname $user_lname<br />
							<a href=\"index.php?page=comments&blogid=$blog_id#comments\">Comments ($comm_count)</a>$editDelete</p>
						</div>
						<div class=\"story\">
							$blog_body
						</div>
					</div>";
			}
		}
		//Start Page breaks for Comments
		$result  = mysql_query("SELECT COUNT(blog_id) AS numrows FROM BLOGS WHERE blog_id != 0") or die('Error, query failed');
		$row     = mysql_fetch_array($result, MYSQL_ASSOC);
		$numrows = $row['numrows'];
		
		$maxPage = ceil($numrows/$rowsPerPage);
		$self = $_SERVER['PHP_SELF'] . "?page=blog" . $blog_get_id;
		$nav  = '';
		
		for($pageNav = 1; $pageNav <= $maxPage; $pageNav++) {
			if ($pageNav == $pageNum) {
				$nav .= " $pageNav "; // no need to create a link to current page
			}
			else {
				$nav .= " <a href=\"$self&pageNav=$pageNav\">$pageNav</a> ";
			}
		} //End For
		if ($pageNum > 1) {
			$pageNav  = $pageNum - 1;
			$prev  = " <a href=\"$self&pageNav=$pageNav\">[Prev]</a> ";				
			$first = " <a href=\"$self&pageNav=1\">[First Page]</a> ";
		}
		else {
			$prev  = '&nbsp;'; // we're on page one, don't print previous link
			$first = '&nbsp;'; // nor the first page link
		}		
		if ($pageNum < $maxPage) {
			$pageNav = $pageNum + 1;
			$next = " <a href=\"$self&pageNav=$pageNav\">[Next]</a> ";
			$last = " <a href=\"$self&pageNav=$maxPage\">[Last Page]</a> ";
		}
		else {
			$next = '&nbsp;'; // we're on the last page, don't print next link
			$last = '&nbsp;'; // nor the last page link
		}
	} //End while
	
	// print the navigation link
	$allNav .= $first . $prev . $nav . $next . $last;
	echo "<br /><hr width=\"100%\" />";
	echo $allNav;
?>