	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>ProjectXFire.com - Russ Teicheira's Home Page</title>
	<meta name="Author" content="Russell L. Teicheira" />
	<meta name="Copyright" content="2007" />
	<meta name="ROBOTS" content="NOINDEX, NOFOLLOW">
	<meta name="Contact" content="projectx@projectxfire.com" />
	<meta name="Description" content="Russ Teicheira's Home Page" />
	<meta name="Keywords" content="Russ, Russell, Teicheira, Lee, Russ Teicheira, Russell Teicheira, Russell Lee Teicheira, Lee Teicheira, Resume, Projects, Web Deveolopment, Java, PHP, MySQL" />
	<link rel="shortcut icon" href="http://projectxfire.com/home/v2/images/favicon.ico" />
	<link href="inc/default.css" rel="stylesheet" type="text/css" />