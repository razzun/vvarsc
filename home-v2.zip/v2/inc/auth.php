<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		elseif($_SESSION[id] == $row[user_session]){	
?>