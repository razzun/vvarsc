		<ul>
			<li <? if($_GET['page'] == 'main' || $_GET['page'] == false){ echo "class=\"active\"";} ?>><a href="index.php?page=main" title="Main Page">Main</a></li>
			<li <? if($_GET['page'] == 'blog' || $_GET['page'] == 'comments' || $_GET['page'] == 'full_blog' || $_GET['page'] == 'comment_blog_post' || $_GET['page'] == 'comment_blog_post_code' || $_GET['page'] == 'blog_post' || $_GET['page'] == 'user_comment_list' || $_GET['page'] == 'comment_edit' || $_GET['page'] == 'blog_edit' || $_GET['page'] == 'comment_delete' || $_GET['page'] == 'comment_delete_code'){ echo "class=\"active\"";} ?>><a href="index.php?page=blog" title="Site Blog/News">Blog</a></li>
			<li <? if($_GET['page'] == 'aboutme'){ echo "class=\"active\"";} ?>><a href="index.php?page=aboutme" title="About Russ Teicheira">About Me</a></li>
			<li <? if($_GET['page'] == 'projects'){ echo "class=\"active\"";} ?>><a href="index.php?page=projects" title="Russ's Current Projects">Projects</a></li>
			<li <? if($_GET['page'] == 'resume'){ echo "class=\"active\"";} ?>><a href="index.php?page=resume" title="Russ's Current Resume">Resume</a></li>
			<li <? if($_GET['page'] == 'links'){ echo "class=\"active\"";} ?>><a href="index.php?page=links" title="Links to External Sites">Links</a></li>
			<? if(!$_SESSION['id']) { ?><li <? if($_GET['page'] == 'signup' || $_GET['page'] == 'register'){ echo "class=\"active\"";} ?>><a href="index.php?page=signup" title="Not a Member?  Sign up!">Sign Up</a></li><? } ?>
			<? if($_SESSION['id']) { ?><li><a href="index.php?method=logout" title="Logout">Logout</a></li><? } ?>
		</ul>