			<?
				$page = $_GET['page'];
				
				switch($page) {
					case "main":
					$content = "main.php";
					break;
					
					case "blog":
					$content = "blog.php";
					break;
					
					case "aboutme":
					$content = "aboutme.php";
					break;
					
					case "projects":
					$content = "projects.php";
					break;
					
					case "resume":
					$content = "resume.php";
					break;
					
					case "links":
					$content = "links.php";
					break;
					
					case "signup":
					$content = "signup.php";
					break;
					
					case "comments":
					$content = "blog_comments.php";
					break;
					
					case "full_blog":
					$content = "full_blog.php";
					break;
					
					case "post_comment":
					$content = "user/post_comment.php";
					break;					
					
					default:
					$content = "main.php";
					break;
				}
				
				include_once($content);
			?>