<?php 
$today = date("Y-m-d"); 

if($_POST[signup_submit]) {  
  if($_POST['fname_input']!='' && $_POST['lname_input']!='' && $_POST['location_input']!='' && $_POST['occupation_input']!='' && $_POST['uname_input']!='' && $_POST['password_input']!='' && $_POST['email_input']!='')   
  {
	  if(checkUnique('user_uname', $_POST['uname_input']) == TRUE)   
	  {
		  if(valid_email($_POST['email_input']) == TRUE)   
		  {
			  if(checkUnique('user_email', $_POST['email_input']) == TRUE)   
			  {
				  if($_POST['password_input'] == $_POST['password2_input'])   
				  {		  
					  $query = mysql_query("INSERT INTO USERS (`user_fname`, `user_lname`, `user_email`, `user_uname`, `user_password`, `user_activation_key`, `user_location`, `user_occupation`, `user_join_date`) VALUES ('".mysql_real_escape_string($_POST['fname_input'])."', '".mysql_real_escape_string($_POST['lname_input'])."', '".mysql_real_escape_string($_POST['email_input'])."', '".mysql_real_escape_string($_POST['uname_input'])."', '".mysql_real_escape_string(md5($_POST['password_input']))."', '".random_string('alnum', 32)."', '".mysql_real_escape_string($_POST['location_input'])."', '".mysql_real_escape_string($_POST['occupation_input'])."', '$today')") or die(mysql_error());  
						
					  $getUser = mysql_query("SELECT user_id, user_fname, user_lname, user_uname, user_email, user_activation_key, user_location, user_occupation, DATE_FORMAT(user_join_date, '%M %d, %Y') u_join_date FROM USERS WHERE user_uname = '".mysql_real_escape_string($_POST['uname_input'])."'") or die(mysql_error());
				
					  if(mysql_num_rows($getUser)==1)  
					  {//there's only one MATRIX :PP
						  $email_send = "webmaster@projectxfire.com";
						  $row = mysql_fetch_assoc($getUser); 
						  /**Start Email to Administrator**/ 
						  $headers =  'From: webmaster@projectxfire.com' . "\r\n" . 
									  'Reply-To: webmaster@projectxfire.com' . "\r\n" .  
									  'X-Mailer: PHP/' . phpversion(); 
						  $subject = "Activation EMail for " . $row['user_fname']." ".$row['user_lname'] . " from ProjectXFire.com"; 
						  $message = "The following user would like to join.\nName: ".$row['user_fname']." ".$row['user_lname']."\nUsername: ".$row['user_uname']."\nEmail: ".$row['user_email']."\nLocation: ".$row['user_location']."\nOccupation: ".$row['user_occupation']."\nJoin Date: ".$row['u_join_date']."\nThis is the activation link to approve them for access: http://projectxfire.com/home/v2/index.php?page=user_confirm&id=".$row['user_id']."&key=".$row['user_activation_key']."\n"; 
						  if(mail($email_send, $subject, $message, $headers)) 
						  {//we show the good guy only one case and the bad one for the rest. 
							  $msg = 'Account created.  An email has been sent to the site administrator for approval.'; 
						  } 
						  else { 
							  $error = 'The account has been created, but the validation email to the administrator was not sent out. Please email the <a href="mailto:webmaster@projectxfire.com?Subject=Account created but validation email failed">webmaster</a> for assistance.'; 
						  }
						  /**End Email to Administrator**/							  
						  
						  /**Start Email to User**/
						  $headers2 =  'From: webmaster@projectxfire.com' . "\r\n" . 
									  'Reply-To: webmaster@projectxfire.com' . "\r\n" .  
									  'X-Mailer: PHP/' . phpversion(); 
						  $subject2 = "Confirmation from ProjectXFire.com"; 
						  $message2 = "Hello ".$row['user_fname']." ".$row['user_lname']."[".$row['user_uname']."].  We recently received a request form this email to be added to our user group.  If this is correct you may disregard this email.  If you did not sign up, please email the webmaster and webmaster@projectxfire.com so we can investigate it.\n\nThis is not an approval email, but an email to confirm that you are in fact the one who signed up.  You will get another email when your account has been activated.\n\nThanks.\nRuss Teicheira"; 
						  if(mail($row['user_email'], $subject2, $message2, $headers2)) 
						  {//we show the good guy only one case and the bad one for the rest. 
							  $msg .= '<br /><br />A confirmation email was sent to the email you provided.'; 
						  } 
						  else { 
							  $error = 'The account has been created, but your validation email was not sent out. Please email the <a href="mailto:webmaster@projectxfire.com?Subject=Account created but validation email to user failed">webmaster</a> for assistance.'; 
						  }
						  /**End Email to User**/		  
						  
					  } 
					  else { 
						  $error = 'There was an error.  Please contact the <a href="mailto:webmaster@projectxfire.com?Subject=Signing Up Error - Retrieval Error">webmaster</a> for assistance.'; 
					  } 			   
				  } 
				  else {       
					  $error = 'Please make sure the password fields match.';     
				  }
			  }
				   
			  else {       
				  $error = 'Sorry, that email has already been registered.  If you think this is in error, please contact the <a href="mailto:webmaster@projectxfire.com?Subject=Email Already in use error">webmaster</a> for assistance.';     
			  }
		  }
		  else {       
			  $error = 'Please enter a valid email address.';     
		  }
	  }
	  else {       
		  $error = 'Sorry, but that username is already in use.';     
	  }
  }
  else {       
      $error = 'All fields are required.  Please fill in missing fields.';     
  }
} 

	echo "<div class=greenText>$msg</div>";
	echo "<div class=redText>$error</div>";
?> 