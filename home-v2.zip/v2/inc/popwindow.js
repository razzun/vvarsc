//<script src="inc/popwindow.js"></script>



var newwindow;
function poptraining(url)
{
	var width  = 700;
	var height = 500;
	//Centers the Window
	var left = (screen.width  - width)/2;
	var top = (screen.height - height)/2;
	var params = 'width='+width+', height='+height;
	params += ', top='+top+', left='+left;
	params += ', scrollbars=yes';
	newwindow=window.open(url,'Description',params);
	if (window.focus) {newwindow.focus()}
}