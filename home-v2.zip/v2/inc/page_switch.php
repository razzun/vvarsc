<?
	$page = $_GET['page'];
	
	switch($page) {
		/****************/
		/** Main Links **/
		/****************/
		case "main":
		$content = "main.php";
		break;
		
		case "blog":
		$content = "blog.php";
		break;
		
		case "aboutme":
		$content = "aboutme.php";
		break;
		
		case "projects":
		$content = "projects.php";
		break;
		
		case "resume":
		$content = "resume.php";
		break;
		
		case "links":
		$content = "links.php";
		break;
		
		case "signup":
		$content = "signup.php";
		break;
		
		case "register":
		$content = "inc/register.php";
		break;
		
		case "comments":
		$content = "blog_comments.php";
		break;
		
		case "full_blog":
		$content = "full_blog.php";
		break;
		
		/****************/
		/** User Links **/
		/****************/
		case "comment_blog_post":
		$content = "user/comment_blog_post.php";
		break;
		
		case "comment_blog_post_code":
		$content = "user/comment_blog_post_code.php";
		break;
		
		case "comment_delete":
		$content = "user/comment_delete.php";
		break;
		
		case "comment_delete_code":
		$content = "user/comment_delete_code.php";
		break;
		
		case "comment_edit":
		$content = "user/comment_edit.php";
		break;
		
		case "comment_edit_code":
		$content = "user/comment_edit_code.php";
		break;
		
		case "email_update":
		$content = "user/email_update.php";
		break;
		
		case "email_update_code":
		$content = "user/email_update_code.php";
		break;
		
		case "password_change":
		$content = "user/password_change.php";
		break;
		
		case "password_lost":
		$content = "user/password_lost.php";
		break;
		
		case "profile_update":
		$content = "user/profile_update.php";
		break;
		
		case "profile_update_code":
		$content = "user/profile_update_code.php";
		break;	
		
		case "pword_change_code":
		$content = "user/pword_change_code.php";
		break;
		
		case "pword_lost_code":
		$content = "user/pword_lost_code.php";
		break;
		
		case "user_comment_list":
		$content = "user/user_comment_list.php";
		break;
		
		/****************/
		/** Admin Page **/
		/****************/
		case "blog_delete":
		$content = "admin/blog_delete.php";
		break;	
		
		case "blog_delete_code":
		$content = "admin/blog_delete_code.php";
		break;
		
		case "blog_edit":
		$content = "admin/blog_edit.php";
		break;	
		
		case "blog_edit_code":
		$content = "admin/blog_edit_code.php";
		break;
		
		case "blog_post":
		$content = "admin/blog_post.php";
		break;	
		
		case "blog_post_code":
		$content = "admin/blog_post_code.php";
		break;
		
		case "comment_delete":
		$content = "admin/comment_delete.php";
		break;	
		
		case "comment_delete_code":
		$content = "admin/comment_delete_code.php";
		break;		
		
		case "member_confirm":
		$content = "admin/member_confirm.php";
		break;
		
		case "member_confirm_code":
		$content = "admin/member_confirm_code.php";
		break;	
		
		case "member_list":
		$content = "admin/member_list.php";
		break;
		
		case "member_suspend":
		$content = "admin/member_suspend.php";
		break;	
		
		case "member_suspend_code":
		$content = "admin/member_suspend_code.php";
		break;		
		
		case "projects_update":
		$content = "admin/projects_update.php";
		break;	
		
		case "projects_update_code":
		$content = "admin/projects_update_code.php";
		break;
		
		case "resume_update":
		$content = "admin/resume_update.php";
		break;	
		
		case "resume_update_code":
		$content = "admin/resume_update.php";
		break;
		
		case "user_confirm":
		$content = "admin/user_confirm.php";
		break;
		
		case "welcome_code":
		$content = "admin/welcome_code.php";
		break;	
		
		case "welcome_update":
		$content = "admin/welcome_update.php";
		break;
		
		/******************/
		/** Default Page **/
		/******************/		
		default:
		$content = "main.php";
		break;
	}
	
	include_once($content);
?>