					<form id="login_form" method="post" action="index.php">
						<fieldset>
							<legend>Sign-In</legend>
							<label for="user_uname_login">Username:</label>
							<input id="user_uname_login" type="text" name="user_uname_login" tabindex="1" value="" />
							<label for="user_password_login">Password:</label>
							<input id="user_password_login" type="password" name="user_password_login" tabindex="2" value="" />
							<input id="login_submit" type="submit" name="submit" tabindex="3" value="Sign In" />
							<p><a href="index.php?page=password_lost">Forgot your password?</a><br />
							<?php echo $error; ?></p>
						</fieldset>
					</form>