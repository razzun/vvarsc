		<?
			$blog_recent_get = @mysql_query("SELECT blog_id, DATE_FORMAT(blog_date,'%M %d, %Y at %l:%i %p') blog_post_date, LEFT(blog_body, 70) b_body
						 FROM BLOGS b
						 WHERE blog_id != 0
						 ORDER BY blog_id DESC
						 LIMIT 5") or die(mysql_error());
			
			while($row = mysql_fetch_array($blog_recent_get)) {
				$blog_id = $row['blog_id'];
				$blog_post_date = $row['blog_post_date'];
				$blog_body = strip_tags($row['b_body']);
				
				echo "
					<ul>
						<li>
							<h3>$blog_post_date</h3>
							<p><a class=\"updates\" href=\"index.php?page=full_blog&blogid=$blog_id\">#$blog_id) $blog_body &#8230;</a></p>
						</li>
					</ul>
				";
			} //End while
		?>