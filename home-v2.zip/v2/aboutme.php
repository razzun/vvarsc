<?
	if(!isset($_SESSION[id])){
		echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=0&ref=".$_GET[page]."\">");
	}
	elseif(isset($_SESSION[id])){
		$result = mysql_query("SELECT user_session FROM USERS WHERE user_uname = '$_SESSION[user_uname]'") or die(mysql_error());
		$row = mysql_fetch_array($result);
	
		if($_SESSION[id] != $row[user_session]){
			session_destroy();
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=1\">");
		}
		if($_SESSION[user_level] >= 3) {
			echo("<meta http-equiv=\"refresh\" content=\"0;url=index.php?scheck=2\">");
		}
		else {
			if($_SESSION[id] == $row[user_session]){		
?>
			<div id="welcome" class="post">
				<h2 class="title">About me</h2><br />
				<img alt="Russ Teicheira" align="left" src="images/me.jpg">
				<strong>Full Name:</strong> Russell Lee Teicheira<br />
				<strong>Date of Birth:</strong> October 27, 1984<br />
				<strong>Place of Birth:</strong> Chico, California<br />
				<strong>Education:</strong><br />
				&nbsp;&nbsp;&nbsp;<i>High School</i>: De La Salle High School<br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Concord, CA<br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gradurated June 2003<br />
				&nbsp;&nbsp;&nbsp;<i>Bachelors Degree</i>: CSU, Chico<br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chico, CA<br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gradurated May 2008<br />
				&nbsp;&nbsp;&nbsp;<i>MBA Program</i>: TBD<br />
				<strong>Bachelor of Science Degree:</strong> Business Information Systems<br />
				<strong>Emphasise:</strong> Management Information Systems<br />
				<br />
				<br />
				<br />
				<br />
				<strong>Work Experience:</strong><br />
				Mt. Diablo YMCA Child Care - Teacher's Aid - September 2002 through March 2003<br />
				Berlex Bioscience (now know as Bayer Pharmaceuticals) - Office and Lab Services - Summers 2002 through 2004<br />
				Berlex Bioscience (now know as Bayer Pharmaceuticals) - Medicinal Chemistry Intern - Summers 2005 through 2006<br />
				Chevron Information Technology Company - IT Professional Intern - Summer 2007<br />
				Chevron Information Technology Company - IT Professional - Starting July 2008<br />
				<br />
				<strong>Background:</strong><br />
				<div align="justify">My name is Russ Teicheira and I am a senior at CSU Chico.  I originally started out in the Computer Science department, but switched to MIS shortly before my first year ended.  I quickly moved through classes within the Business department, emphasizing in data security & privacy and networking.  I quickly joined the <a href="http://www.chicomis.org" target="_blank">Management Information Systems Society</a>.  After a year as a member I moved into the Web Developer officer position, before ascending to Treasurer and Vice President.  In the Fall of 2007 I took over as President of the MIS Society, and that is where we are at today.<br />
				<br />
				I have one year left, eight classes left.  I have completed an internship with Chevron over the 2007 summer.  Before that I did some work for Berlex Bioscience, now know as Bayer Pharmaceuticals.  There I did shipping & receiving with some work in lab service for a couple of summers before working on a chemical database for a couple of other summers.  At Chevron I worked in Desktop Support supporting over 700 users.  I took care of anything from software issues to hardware issues to printer issues to a number of other things.<br />
				<br />So this is where I stand right now.<br />
				<br />-Russ</div>
			</div>
<?
			}
		}
	}
?>